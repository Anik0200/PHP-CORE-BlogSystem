<?php

$conn = mysqli_connect("localhost", "root", "", "news-site")

        or die("connection failed : " . mysqli_connect_error());

?>